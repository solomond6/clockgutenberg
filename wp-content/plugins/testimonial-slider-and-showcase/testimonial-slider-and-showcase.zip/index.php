<?php
echo "Silent is gold";